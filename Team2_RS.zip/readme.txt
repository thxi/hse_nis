The spread based strategy is implemented in Agent.py

Data collection and calculations for plots and results table is in NIPS.ipynb jupyter notebook

The collected stock data is in stocks.csv file.
